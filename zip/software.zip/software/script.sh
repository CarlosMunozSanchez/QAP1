seed=42

./BIN/QAP_1 ./DATOS/chr22a.dat $seed ./DATOS/chr22a.sln > ejecuciones.out
./BIN/QAP_1 ./DATOS/chr22b.dat $seed ./DATOS/chr22b.sln >> ejecuciones.out
./BIN/QAP_1 ./DATOS/chr25a.dat $seed ./DATOS/chr25a.sln >> ejecuciones.out
./BIN/QAP_1 ./DATOS/esc128.dat $seed ./DATOS/esc128.sln >> ejecuciones.out
./BIN/QAP_1 ./DATOS/had20.dat $seed ./DATOS/had20.sln >> ejecuciones.out
./BIN/QAP_1 ./DATOS/lipa60b.dat $seed ./DATOS/lipa60b.sln >> ejecuciones.out
./BIN/QAP_1 ./DATOS/lipa80b.dat $seed ./DATOS/lipa80b.sln >> ejecuciones.out
./BIN/QAP_1 ./DATOS/nug28.dat $seed ./DATOS/nug28.sln >> ejecuciones.out
./BIN/QAP_1 ./DATOS/sko81.dat $seed ./DATOS/sko81.sln >> ejecuciones.out
./BIN/QAP_1 ./DATOS/sko90.dat $seed ./DATOS/sko90.sln >> ejecuciones.out
./BIN/QAP_1 ./DATOS/sko100a.dat $seed ./DATOS/sko100a.sln >> ejecuciones.out
./BIN/QAP_1 ./DATOS/sko100f.dat $seed ./DATOS/sko100f.sln >> ejecuciones.out
./BIN/QAP_1 ./DATOS/tai100a.dat $seed ./DATOS/tai100a.sln >> ejecuciones.out
./BIN/QAP_1 ./DATOS/tai100b.dat $seed ./DATOS/tai100b.sln >> ejecuciones.out
./BIN/QAP_1 ./DATOS/tai150b.dat $seed ./DATOS/tai150b.sln >> ejecuciones.out
./BIN/QAP_1 ./DATOS/tai256c.dat $seed ./DATOS/tai256c.sln >> ejecuciones.out
./BIN/QAP_1 ./DATOS/tho40.dat $seed ./DATOS/tho40.sln >> ejecuciones.out
./BIN/QAP_1 ./DATOS/tho150.dat $seed ./DATOS/tho150.sln >> ejecuciones.out
./BIN/QAP_1 ./DATOS/wil50.dat $seed ./DATOS/wil50.sln >> ejecuciones.out
./BIN/QAP_1 ./DATOS/wil100.dat $seed ./DATOS/wil100.sln >> ejecuciones.out
